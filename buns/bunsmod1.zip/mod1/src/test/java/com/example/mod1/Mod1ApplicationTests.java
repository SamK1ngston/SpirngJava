package com.example.mod1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Mod1ApplicationTests {

    @Test
    void contextLoads() {
    }

}
