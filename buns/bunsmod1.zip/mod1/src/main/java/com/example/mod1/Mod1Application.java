package com.example.mod1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Mod1Application {

    public static void main(String[] args) {
        SpringApplication.run(Mod1Application.class, args);
    }

}
