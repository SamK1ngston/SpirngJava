package com.example.mod2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Mod2ApplicationTests {

    @Test
    void contextLoads() {
    }

}
